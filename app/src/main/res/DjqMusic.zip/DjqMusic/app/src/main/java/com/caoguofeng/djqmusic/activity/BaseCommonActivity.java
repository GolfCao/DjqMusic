package com.caoguofeng.djqmusic.activity;

class BaseCommonActivity extends BaseActivity{

}
