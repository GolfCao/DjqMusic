package com.caoguofeng.djqmusic.util;

import com.caoguofeng.djqmusic.BuildConfig;

public class Consts {
    public static final String ENDPOINT = BuildConfig.ENDPOINT;
    public static final String RESOURCE_PREFIX = BuildConfig.RESOURCE_PREFIX;

}
