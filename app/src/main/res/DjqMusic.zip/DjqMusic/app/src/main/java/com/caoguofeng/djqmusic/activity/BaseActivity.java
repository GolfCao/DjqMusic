package com.caoguofeng.djqmusic.activity;

import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;

import android.support.v7.app.AppCompatActivity;

class BaseActivity extends AppCompatActivity {
    /**
     * 初始化控件
     */
    protected void initViews() {

    }

    /**
     * 绑定数据
     */
    protected void initDatas() {

    }

    /**
     * 绑定监听器
     */
    protected void initListener() {

    }

    public void init() {
        initViews();
        initDatas();
        initListener();
    }

    /**
     * 绑定view的时候就初始化
     * @param layoutResID
     */
    @Override
    public void setContentView(int layoutResID) {
        super.setContentView(layoutResID);
        init();
    }

    /**
     * 绑定view的时候就初始化
     * @param view
     */
    @Override
    public void setContentView(View view) {
        super.setContentView(view);
        init();
    }

    /**
     * 绑定view的时候就初始化
     * @param view
     * @param params
     */
    @Override
    public void setContentView(View view, ViewGroup.LayoutParams params) {
        super.setContentView(view, params);
        init();
    }

//    protected void startActivity(Class<?> clazz) {
//        startActivity(new Intent(getActivity(), clazz));
//    }
}
